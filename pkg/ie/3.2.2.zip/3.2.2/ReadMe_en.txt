------------------------------
     A HREF++     Ver3.2.2    
------------------------------
 2013/11/24

* About
  - Right click extention for Internet Explorer.
  - Open the URLs included in selected string even if the URL is incomplete.
    (Ex. "ttp://example.com/" "http:/example.com/" )
  - See this page.
    http://irts.jp/program/browserplugin/ahrefplusplus_en/

* Usage
  - Select URLs(not Hyperlinked), then rignt click and execute "A HREF++".
  - Here is the practice page for "A HREF++".
    http://irts.jp/program/browserplugin/ahrefplusplus_en/#practice

* Install/Uninstall
  - Double click "A_HREF_plusplus_SetUp.vbs".

* Environment
  - InternetExplorer 9/10/11
  - Windows 8/7/Vista

* Tips
  - In case some security software alert you when you install "A HREF++",
    please permit this program. 
  - When you open many URLs by "A HREF++" at once, Pop-up Blocker may block
    opening windows. Please turn off Pop-up Blocker as necessary.
  - I recommend you to change Tabs Setting of "Internet Options",
    "Let InternetExplorer decide how pop-ups should open" or "Always open
    pop-ups in a new tab".

* Contact
   Author : murachika
  Website : http://irts.jp/

* Changelog
  - 2013/11/24   Ver3.2.2
   -- Fix for Internet Explorer 11.

  - 2011/08/13   Ver3.2.1
   -- Added regular expression "!".

  - 2010/11/30   Ver3.2
   -- Separate en/ja version.

  - 2010/11/23   Ver3.1
   -- Fix wrong regular expression.

  - 2010/11/1    Ver3.0
   -- Fix for Windows7/Vista 64bit
